// Sends the shop owner a WhatsApp message whenever a new order is inserted.
// Triggered by a Supabase Database Webhook on public.orders (INSERT).
// Uses CallMeBot, a free service that messages your own WhatsApp number.

const t12 = (h: number) => `${h % 12 || 12}:00 ${h < 12 ? "AM" : "PM"}`;

function buildMessage(o: Record<string, any>): string {
  const d = new Date(`${o.slot_date}T00:00:00Z`).toLocaleDateString("en-IN", {
    weekday: "short", day: "numeric", month: "short", timeZone: "UTC",
  });
  const L = [
    `New order ${o.order_no}`,
    `${o.name}, ${o.phone}`,
    `${o.type}: ${d}, ${t12(o.slot_hour)} to ${t12(o.slot_hour + 1)}`,
  ];
  const items = Array.isArray(o.items) ? o.items : [];
  if (items.length) L.push("Items: " + items.map((i: any) => `${i.name} ${i.unit} x${i.qty}`).join(", "));
  if (o.has_photo) L.push("Handwritten list: open the app to view.");
  if (o.address) L.push("Address: " + o.address);
  if (o.note) L.push("Note: " + o.note);
  L.push((o.total == null ? "Total to be confirmed" : `Total Rs ${o.total}`) + `, pay by ${o.payment}`);
  return L.join("\n").slice(0, 900);
}

Deno.serve(async (req) => {
  const secret = Deno.env.get("WEBHOOK_SECRET");
  if (!secret || req.headers.get("x-webhook-secret") !== secret) {
    return new Response("forbidden", { status: 403 });
  }
  const payload = await req.json().catch(() => null);
  if (!payload || payload.type !== "INSERT" || payload.table !== "orders") {
    return new Response("ignored", { status: 200 });
  }
  const phone = Deno.env.get("OWNER_WHATSAPP");
  const key = Deno.env.get("CALLMEBOT_APIKEY");
  if (!phone || !key) return new Response("alert settings missing", { status: 500 });

  const url = "https://api.callmebot.com/whatsapp.php?phone=" + encodeURIComponent(phone) +
    "&text=" + encodeURIComponent(buildMessage(payload.record)) +
    "&apikey=" + encodeURIComponent(key);
  const r = await fetch(url);
  return new Response(await r.text(), { status: r.ok ? 200 : 502 });
});
