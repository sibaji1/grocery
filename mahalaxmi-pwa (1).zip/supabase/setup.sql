-- Mahalaxmi Stores: orders table and access rules.
-- 1) Replace OWNER_EMAIL below (2 places) with the shop owner's email.
-- 2) Paste the whole file into Supabase > SQL Editor > Run.

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  order_no text not null,
  name text not null,
  phone text not null,
  type text not null check (type in ('Pickup','Delivery')),
  address text,
  note text,
  slot_date date not null,
  slot_hour int not null check (slot_hour between 9 and 19),
  items jsonb not null default '[]'::jsonb,
  has_photo boolean not null default false,
  list_photo text,
  subtotal numeric not null default 0,
  delivery numeric not null default 0,
  total numeric,
  payment text not null check (payment in ('Cash','UPI')),
  status text not null default 'new' check (status in ('new','packed','done','cancelled'))
);

alter table public.orders enable row level security;

-- Customers (not signed in) can place an order, and nothing else.
drop policy if exists "customers place orders" on public.orders;
create policy "customers place orders" on public.orders
  for insert to anon, authenticated
  with check (status = 'new');

-- Only the shop owner can read and update orders.
drop policy if exists "owner reads orders" on public.orders;
create policy "owner reads orders" on public.orders
  for select to authenticated
  using ((auth.jwt() ->> 'email') = 'OWNER_EMAIL');

drop policy if exists "owner updates orders" on public.orders;
create policy "owner updates orders" on public.orders
  for update to authenticated
  using ((auth.jwt() ->> 'email') = 'OWNER_EMAIL')
  with check ((auth.jwt() ->> 'email') = 'OWNER_EMAIL');
